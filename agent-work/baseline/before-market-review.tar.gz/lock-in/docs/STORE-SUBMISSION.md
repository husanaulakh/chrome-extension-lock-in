# Store submission preparation

The build produces separate Manifest V3 ZIPs for Chromium and Firefox. They include icons, a bundled dashboard, guide and privacy page, and no remotely executed code. Firefox uses a background module script; Chromium uses a module service worker. Mozilla's data collection declaration is `none`; Firefox minimum is 142.

## Listing copy

Name: Lock in

Summary: Keep the pages your task needs. Set a focus session, manage distractions, and review your progress.

Description: Choose a task and its allowed websites or exact pages. Block selected domains, customize temporary access and exit delay, and add time when needed. Review completed sessions in Dashboard. All features are available without payment or an account. Records stay in your browser. Incognito/private coverage requires browser permission; private attempts are excluded from reports. Technical recovery is always available.

Single purpose: Help the user maintain a chosen browsing boundary during a timed focus session.

## Permission explanations

| Permission | Purpose |
| --- | --- |
| storage | Save regular sessions and keep private sessions in memory |
| alarms | Reconcile expired sessions and grants |
| tabs | Check existing tab destinations and open the block page/dashboard |
| webNavigation | Detect full URL, fragment and History API changes |
| declarativeNetRequest | Redirect disallowed top-level pages |
| HTTP(S) host access | Apply user-selected boundaries across websites |

## Publisher steps remaining

A publisher must supply their real account identity, support contact, hosted privacy-policy URL and listing assets, then submit for review. Do not substitute a placeholder contact. The Gecko ID is `lock-in@focus.invalid`; choose a stable publisher-owned ID before the first public release if desired. Signing and store approval cannot be inferred from a successful lint run. No listing has been submitted.

Use actual product captures from `artifacts/` as the basis for store images. Chrome screenshots must meet the store's current dimensions; crop or capture at 1280×800, with no unsupported browser or effectiveness claims. Review private mode on the target stable browser and operating system before release.

## Sources

- [Chrome program policies](https://developer.chrome.com/docs/webstore/program-policies/policies)
- [Chrome listing images](https://developer.chrome.com/docs/webstore/images)
- [Mozilla add-on policies](https://extensionworkshop.com/documentation/publish/add-on-policies/)
- [Firefox data consent](https://extensionworkshop.com/documentation/develop/firefox-builtin-data-consent/)
- [Background contexts](https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/manifest.json/background)
- [Chrome incognito contexts](https://developer.chrome.com/docs/extensions/reference/manifest/incognito)
