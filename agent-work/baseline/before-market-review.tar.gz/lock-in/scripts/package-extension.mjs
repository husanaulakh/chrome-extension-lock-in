import { copyFile, mkdir, readFile, writeFile, cp } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { LockKeyhole } from 'lucide-react';
const require = createRequire(import.meta.url);
// Reuse the renderer already installed with the build toolchain.
const sharp = require(
  require.resolve('sharp', { paths: [require.resolve('wrangler')] }),
);
await copyFile('core/engine.mjs', 'extension/engine.mjs');
await copyFile('LICENSE', 'extension/LICENSE');
await mkdir('extension/icons', { recursive: true });
const icon = renderToStaticMarkup(
  React.createElement(LockKeyhole, {
    width: 62,
    height: 62,
    color: 'white',
    strokeWidth: 1.6,
  }),
);
const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128"><rect width="128" height="128" rx="30" fill="#1d1d1f"/><g transform="translate(33 30)">${icon}</g></svg>`;
for (const size of [16, 32, 48, 96, 128])
  await sharp(Buffer.from(svg))
    .resize(size, size)
    .png()
    .toFile(`extension/icons/icon-${size}.png`);
await writeFile('public/icon.svg', svg);
await mkdir('public/docs', { recursive: true });
for (const file of [
  'README.md',
  'EXTENSION.md',
  'BUSINESS.md',
  'ARCHITECTURE.md',
  'TESTING.md',
  'VALIDATION.md',
  'PRIVACY.md',
  'STORE-SUBMISSION.md',
]) {
  await copyFile(
    file === 'README.md' ? file : `docs/${file}`,
    `public/docs/${file}`,
  );
}
const manifest = JSON.parse(await readFile('extension/manifest.json', 'utf8'));
for (const browser of ['chromium', 'firefox']) {
  const dest = `releases/${browser}`;
  await mkdir(dest, { recursive: true });
  await cp('extension', dest, { recursive: true });
  const configured = structuredClone(manifest);
  if (browser === 'firefox') {
    configured.background = { scripts: ['background.mjs'], type: 'module' };
    configured.incognito = 'spanning';
    delete configured.minimum_chrome_version;
    configured.browser_specific_settings = {
      gecko: {
        id: 'lock-in@focus.invalid',
        strict_min_version: '142.0',
        data_collection_permissions: { required: ['none'] },
      },
    };
  }
  await writeFile(
    `${dest}/manifest.json`,
    JSON.stringify(configured, null, 2) + '\n',
  );
  execFileSync('python3', [
    '-c',
    "import pathlib,zipfile,sys; root=pathlib.Path(sys.argv[1]); z=zipfile.ZipFile(sys.argv[2],'w',zipfile.ZIP_DEFLATED); [z.write(p,p.relative_to(root)) for p in sorted(root.rglob('*')) if p.is_file()]; z.close()",
    dest,
    `public/lock-in-${browser}.zip`,
  ]);
}
await copyFile('public/lock-in-chromium.zip', 'public/lock-in-extension.zip');
console.log('Packaged Chromium and Firefox extensions.');
